#ifndef __PANIC_HEADER__
#define __PANIC_HEADER__

void __attribute__((noreturn)) panic(uint8_t *s);

#endif
