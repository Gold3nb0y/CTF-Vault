#!/bin/bash
#
gcc -masm=intel -fno-stack-protector -nostdlib -fno-builtin entry.S exp.c syscall.c lib.c -o exploit
./upload.sh $docker_id exploit
