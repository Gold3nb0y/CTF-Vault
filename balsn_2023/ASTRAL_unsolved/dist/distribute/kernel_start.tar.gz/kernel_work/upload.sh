#!/bin/bash
#
docker cp $2 $1:/home/Astral/$2
