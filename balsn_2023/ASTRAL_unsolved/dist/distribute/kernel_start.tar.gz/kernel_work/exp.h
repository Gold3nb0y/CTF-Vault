#ifndef __USER_HEADER__
#define __USER_HEADER__

#include <stddef.h>
#include <stdint.h>
#include "lib.h"
#include "syscall.h"

#define SUCCESS 0
#define FAIL 0xffffffffffffffff

#endif
