#include "exp.h"
#include "syscall.h"
#include <stdint.h>

void* mcpy(uint8_t* dst, uint8_t* src, uint64_t size){
    for(; size > 0; size--, dst++, src++)
        *dst = *src;
}

int lolMain(){
    uint8_t* mapping;
    char* lol = "LOLOLOLOLOL\n";
    uint8_t bytes_read;


    puts((uint8_t*)"starting usermode binary");

    mapping = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    puts("mapping complete");


    memcpy_local(mapping, lol, strlen_local(lol));
    
    puts(mapping);

    puts("finish");

    return SUCCESS;
}
