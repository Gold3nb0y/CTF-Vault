#!/usr/bin/env python3

from pwn import *
import base64
import hashlib


HOST = os.environ.get('HOST', 'localhost')
PORT = 31337

hashes = {
        "9a444e57e3cc0e1644e89ad8e1e275e5":  "07402ae4f06297c77c99599067b46a79",
        "1b191ef864490b78f9de56b28bf2550f":  "0b7ea2bb6725cf6158f39894e3d8fc0c",
        "34f96a8ce9920caa6a01750312c3575a":  "1bcb8edab8fb41de17ce26420acbf3a5",
        "33de54fdd5975740b630c64f458ca20b":  "26922ac31e43e6ae20524c4c9b711b3d",
        "95cb0b3b0dc2d9a4dc1e65901c8f1ef4":  "2fafe278392358d1e09a93673a889b16",
        "bff56042556e0b13df8689dac6bf8c99":  "3328aee2a31f26d767447d2b378a1ae1",
        "f481dfae3fccfce3edf6e887cd737277":  "42b2383eee529098d3d091f9788aac4e",
        "ac442c212482b792c75581d83ab4f354":  "479bc770cba7ff96632891d4d638e73e",
        "97a5883a62b125497b01811dec8f63ea":  "5895244c5d843bd95dd63e0e07218f2e",
        "17ba0a146e7d79bff91c135604a07dae":  "63fe5e6115a97e71ea47e494a9a8bea5",
        "061dc1e227c6e1b566a498382b6f52bc":  "6501ffeb4888a55942b2480c712db51b",
        "d78cd415a6e3b536209a498f7280ee30":  "65a52fae99ee9a03f964d74f4287e7bd",
        "668fbf706920c5fed0c4a904f8e4403e":  "97358c82be5d670397c0a16e63a2e5de",
        "50df4c4b6fe0f4997a0d69581f49f8c9":  "9cd7898cf6d6f2440261f57961c97d69",
        "cee167f5dcc2bc154f724f00374aa1b2":  "bb027600f022e17bb456c08b3d758049",
        "dc73ae2b91bff3105c5315404b9846c4":  "ddebc6ba5a7e9cbd52bb21d2119c54bf",
        "c9de8473989369175ec88186adfc8fd4":  "e3aea7747b919ff838704ed3a6b6b28f",
        "0fca8f08675cfec74d150f503e32b425":  "ea8290fb658e89c728d1948ba95af67c",
        "9ecae7665cc090eb496b7056ad74cef5":  "f352c0dcd56a8ba664566c64df41b2b3",
        "50453d50481a7269a4e5e59370458d80":  "f7785e233f41c48fa4b767f23e244408",

        }

io = remote(HOST, int(PORT))
for i in range(20):
    io.recvuntil(b"Crackme: ")

    crackme_encoded = io.recvline().strip()

    crackme = base64.b64decode(crackme_encoded)
    #log.info(f"length of file decoded {len(crackme)}")
    hash = hashlib.md5(crackme).hexdigest()
    #log.info(f"the hash is {hash}")
    password = hashes[hash]
    #log.info(f"the password is {password}")
    io.sendlineafter(b"Password: ", password)

io.recvuntil(b"flag: ")
flag = io.recvline_contains(b'LiveCTF{').decode().strip()
log.info('Flag: %s', flag)
