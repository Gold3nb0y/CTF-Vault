#include <stddef.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

int shrmem_id;
void* shrmem_head;
FILE* chat_file;
char key[8];
char filename[16];

#define MSG_SIZE = 0xe0;


//TODO: IMPLEMENT FILE LOCKING SO THAT THE PROCESSES CAN WORK IN SYNC

typedef struct message{
    uint64_t next;
    char name[0x10];
    char message[0xe0];
} message;

void setup(){
    shrmem_id = shmget(IPC_PRIVATE, 0x1000, 0666);
    if(shrmem_id==-1){
        puts("Failed to allocated server memory, exiting");
        exit(-1);
    } else { 
        printf("Server id: %d\n", shrmem_id);
    }
   
    shrmem_head = shmat(shrmem_id, (void*)0, 0);
    if((int)shrmem_head == -1){
        puts("Could not connect to server memory");
        exit(-1);
    }

    memset(filename, 0, 10);
    memcpy(filename, "/tmp/", 5);
    char temp[6];
    memset(temp, 0, 6);
    int fid = open("/dev/urandom",O_RDONLY);
    char c;
    uint count = 0;
    while(count < 5){
        read(fid, &c, 1);
        if(c > 0x40 && c < 0x5b){
            temp[count] = c;
            count++;
        }
    }
    strcat(filename, temp);
    strcat(filename, ".txt");

    chat_file = fopen(filename, "w+");

    if(!chat_file){
        puts("Failed to create a new chatroom");
        exit(-1);
    }
    //printf("Created a new chatroom with the name: %s",temp); 

    memset(shrmem_head, 0, 0x1000);
    memcpy(shrmem_head+0x10, filename, 14);

    memset(key, 0, 8);
    read(fid, key, 8);
    close(fid);

    fclose(chat_file);
    puts("Server setup complete, please enter the server ID into a client process to connect!");
    return;
}

void cleanup(int sig_num){
    memcpy(shrmem_head+0x9, "DONE\x00", 5);
    sleep(5); //give the clients time to detach;
    int err = shmctl(shrmem_id, IPC_RMID, 0); //free the shared memory segment
    if(chat_file != NULL) fclose(chat_file);
    remove(filename);
    exit(0); //successful finish
}

int filter(char* mes){
    puts("No filter yet");
    return 0;
}

char* parse_message(struct message* message_ptr){
    char* mes = malloc(0x100);
    strncpy(mes, message_ptr->message,0xe0);
    printf("%s\n",mes);
    filter(mes);
    return mes;
}

void server_loop(){
    struct message* blank_msg = malloc(sizeof(struct message));
    uint count = 1;
    char* mes;
    blank_msg->next = 0;
    int done = 0;
    while (1) {
        struct message* message_head = (struct message*)(shrmem_head+0x100); 
        sleep(2);
        if(message_head->next != 0){
            chat_file = fopen(filename, "a");
            if(chat_file == NULL) exit(-1);
            memcpy(shrmem_head, key, 8); //copy the key to lock the file
            while (message_head->next != 0) {
                mes = parse_message(message_head);
                if(strcmp(mes,"!exit\x00") == 0){
                    done = 1;
                    break;
                }
                //todo fix the size
                fprintf(chat_file, "%s\n","----message start----");
                fprintf(chat_file, "%s",message_head->name);
                fprintf(chat_file, "%s",mes);
                fprintf(chat_file, "%s\n","----message break----");
                printf("message head: 0x%llx\n", message_head);
                count++;
                message_head = (struct message*)(shrmem_head+(0x100*count));
                printf("message head2: 0x%llx\n", message_head);
                free(mes);
            }
            puts("closing the file");
            fclose(chat_file);
            chat_file = NULL;
            if(done) break;
            memset(shrmem_head+0x100, 0,0xf00); //clear out the messages
            memcpy(shrmem_head+0x100, blank_msg, sizeof(struct message)); //restart the chain
            memset(shrmem_head, 0, 8); //clear out the lock
        }
    }
    free(blank_msg);
    return;
}

int main(int argc, char* argv[]){
    setup();
    signal(SIGINT, cleanup);
    signal(SIGALRM, cleanup);
    alarm(120); //set an alarm to trigger after 2 minutes that cleans everything up
    server_loop();
    cleanup(0);
}
