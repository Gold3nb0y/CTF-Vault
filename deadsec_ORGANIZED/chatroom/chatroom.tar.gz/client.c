#include <stddef.h>
#include <assert.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

void* shrmem_head = NULL;
int shrmem_id;
char chat_filename[0x10];
FILE* chatroom;
char username[16];
char* read_line;
int pid;
int username_size;

#define MSG_MAX_SIZE = 0xe0;

typedef struct message{
    uint64_t next;
    char name[0x10];
    char message[0xe0];
} message;


//setup the process to work on remote
void setup(){
    setvbuf(stdin,(char*)0x0,2,0);
    setvbuf(stdout,(char*)0x0,2,0);
    setvbuf(stderr,(char*)0x0,2,0);
    return;
}

void overwrite_stdout(){
    printf("%s", "> ");
    fflush(stdout);
}

//connect to the target server and read the filename
void connect(){
    printf("please enter the id of the server you'd like to connect to: ");
    char number[0x20];
    read(0, number, 0x1f); 
    shrmem_id = atoi(number);
    shrmem_head = shmat(shrmem_id, (void*)0, 0);
    if((int)shrmem_head == -1){
        puts("Could not connect to server");
        exit(-1);
    }
    memset(chat_filename, 0, 0x10);
    memcpy(chat_filename, (char*)(shrmem_head+0x10), 14);
    printf("LOG filename: %s\n", chat_filename);
    chatroom = fopen(chat_filename, "r");
    if(chatroom == NULL){
        puts("failed to open chatfile");
        exit(-1);
    }
    fclose(chatroom);
    memset(username, 0, 16);
    printf("Please give a username(max size of 15): ");
    username_size = read(0, username, 15)-1;
    
    read_line = malloc(0x420);
    return;
}

//detach from the server and safely close
void cleanup(int sig_num){
    shmdt(shrmem_head);
    if(chatroom != NULL) fclose(chatroom);
    free(read_line);
    kill(pid, SIGKILL);
}

int parse_recvd_msg(){
    char* tosend = malloc(0x420);
    ssize_t bytes_read = 0;
    ssize_t count = 0;
    size_t len = 0;
    char name[16];

    bytes_read = getline(&read_line,&len, chatroom);
    if(bytes_read == -1) return;
    memcpy(name, read_line, bytes_read-1);

    bytes_read = getline(&read_line, &len, chatroom);
    assert(bytes_read != -1);
    int i = 1;
    while(strncmp(read_line, "----message break----", 21)!=0 && count < 0x420){
        memcpy(tosend+count, read_line, bytes_read);
        count += bytes_read;
        bytes_read = getline(&read_line, &len, chatroom);
        i++;
    }

    if(strncmp(username, name, username_size) == 0) return 0;

    printf("[%s]: ", name);
    write(1, tosend, count);
    return 1;
}

//a forked process attaches and reads the new messages from the chatroom
void read_loop(){
    int message_count = 0;
    while(1){
        size_t len = 0;
        sleep(2);
        chatroom = fopen(chat_filename, "r");
        if(chatroom == NULL) exit(-1);
        int temp_count = 0;
        int overwrite = 0;
        while(getline(&read_line, &len, chatroom) != -1){
            if(strncmp(read_line,"----message start----", 21) == 0){
                //puts("MATCHED");
                if(temp_count < message_count){
                    temp_count++;
                } else {
                    overwrite = parse_recvd_msg() || overwrite;
                    message_count++;
                    temp_count++;
                }
            }
            if(overwrite) overwrite_stdout();
        }
        fclose(chatroom);
        chatroom = NULL;
    }
}

//allows a user to exit and also send messages to the server
void input_loop(){
    char option[0x10];
    struct message* msg_head = (struct message*)(shrmem_head+0x100);
    overwrite_stdout();
    struct message* tosend = (struct message*)malloc(0x100);
    memset(tosend, 0, 0x100);
    memcpy(tosend->name, username, 16);
    while(1){
        read(0, option, 0xf); 
        if(strcmp(option,"exit")==0){
            cleanup(0);
        }
        else if(strcmp(option,"chgusr") == 0) {
            memset(username, 0, 16);
            read(0, username, 15);
            memcpy(tosend->name, username, 16);
        } else {
            while(msg_head->next != 0){
                msg_head = (struct message*)(msg_head+0x100);
            }
            memcpy(msg_head, tosend, 0x100);
            fgets(msg_head->message, 0xdf, stdin);
            msg_head->next = 0x1337CA7;
        }
        msg_head = (struct message*)(shrmem_head+0x100);
        overwrite_stdout();
    }
}

//launch everything
int main(int argv, char* argc[]){
    setup();
    connect();
    signal(SIGINT, cleanup);
    signal(SIGALRM, cleanup);
    alarm(120); //set an alarm to trigger after 2 minutes that cleans everything up
    pid = fork();
    if(pid == 0){
        read_loop();
    } else {
        input_loop();
        cleanup(0);
    }
}
