#!/bin/bash

gcc client.c -o client -lpthread -lrt
gcc server.c -o server -lpthread -lrt
